package slidinggame;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class SlidingGamePlayer {

	private SlidingGameState state;
	
	private Queue<SlidingGameState> queue;

	public SlidingGamePlayer(SlidingGameState newState)
	{
		state = newState;
		queue = new LinkedList<SlidingGameState>();
	}

	public String planGame() throws Exception
	{
		int[] index = {1,-1};String answer="No solution"; boolean win=false; SlidingGameState tempGame;ArrayList<SlidingGameState> moves = new ArrayList<SlidingGameState>();boolean stop=false;
		moves.add(state);          //add initial state to moves
		queue.add(state);          //add initial state to queue
		while (!queue.isEmpty()) {
			state = queue.poll();
			if (state.isWin()) {   //is this state a win?
				win=true;
				answer = state.getSequence();
			}
			if (win)                          //Break out of the while loop if the game has ben won
				break;
				
			for (int num : index)  {
				if (this.state.isValid(num,0)){      //Is this move valid
					tempGame= new SlidingGameState(state);  //create a copy of the state
					tempGame.moveToken(num, 0);               //make the move
					for (SlidingGameState old: moves) {
						if (old.equals(tempGame))           //if this state has already been explored don't put it on the queue (A)
							stop=true;
					}
					if(!stop) {								//if this state has already been explored don't put it on the queue (B)
					queue.add(tempGame);                    //Add it to the queue
					moves.add(tempGame);                    //add it to the array list
					}
					stop=false;
				} //end if
			    } //end for
				
			for (int num : index)  {
				if (this.state.isValid(0,num)){      //Is this move valid
					tempGame= new SlidingGameState(state);  //create a copy of the state
					tempGame.moveToken(0, num);               //make the move
					for (SlidingGameState old: moves) {
						if (old.equals(tempGame))           //if this state has already been explored don't put it on the queue (A)
							stop=true;
					}
					if(!stop) {								//if this state has already been explored don't put it on the queue (B)
					queue.add(tempGame);                    //Add it to the queue
					moves.add(tempGame);                    //add it to the array list
					}
					stop=false;
				} //end if
			    } //end for
		 
		
		
		}//end while

		return answer;
	}

}